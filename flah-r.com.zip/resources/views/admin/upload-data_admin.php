<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>لوحة تحكم الادمن</title>
</head>
<body>
  <h2>مرحباً بك في لوحة تحكم الادمن</h2>
</body>
</html>
